-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2019 at 01:49 PM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payroll`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_03_04_124320_create_tbl_admin_table', 1),
(2, '2019_03_04_130148_create_tbl_about_team_table', 2),
(3, '2019_03_04_130458_create_tbl_slider_table', 3),
(4, '2019_03_04_140230_create_tbl_office_table', 4),
(5, '2019_03_04_160006_create_tbl_unit_table', 5),
(6, '2019_03_04_181513_create_tbl_designation_table', 6),
(7, '2019_03_04_182326_create_tbl_department_table', 7),
(8, '2019_03_04_191007_create_tbl_grade_table', 8),
(9, '2019_03_04_202902_create_tbl_employee_table', 9),
(10, '2019_03_04_221300_create_tbl_attendance_table', 10),
(11, '2019_03_17_191652_create_tbl_leave_table', 11),
(12, '2019_04_13_012457_create_tbl_festible_table', 12),
(13, '2019_04_16_173643_create_tbl_salary_table', 13);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(10) UNSIGNED NOT NULL,
  `admin_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `admin_type` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email`, `admin_phone`, `admin_user`, `admin_password`, `admin_type`, `created_at`, `updated_at`) VALUES
(1, 'jewel', 'jewel@bgmea.com', '01814766106', 'jewel', '202cb962ac59075b964b07152d234b70', 'admin', NULL, NULL),
(2, 'Mainul Hasan', 'mainul@gmail.com', '01446463235', 'mainul', '202cb962ac59075b964b07152d234b70', 'hr-manager', NULL, NULL),
(3, 'Kamrul Hasan', 'kamrulhasan@gmail.com', '01456546552', 'kamrul', '202cb962ac59075b964b07152d234b70', 'manager', NULL, NULL),
(4, 'Sibly Noman', 'sibly@bexximco.com', '02145596555', 'sibly', '202cb962ac59075b964b07152d234b70', 'data-entry', NULL, NULL),
(5, 'Abdullah Khan', 'abdullah@beximco.com', '01547854455', 'abdullah', '202cb962ac59075b964b07152d234b70', 'accountant', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_attendance`
--

CREATE TABLE `tbl_attendance` (
  `id` int(10) UNSIGNED NOT NULL,
  `employee_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `shift_id` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attendance_date` date NOT NULL,
  `in_time` time DEFAULT NULL,
  `out_time` time DEFAULT NULL,
  `attendance_status` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_attendance`
--

INSERT INTO `tbl_attendance` (`id`, `employee_id`, `unit_id`, `shift_id`, `attendance_date`, `in_time`, `out_time`, `attendance_status`, `created_at`, `updated_at`) VALUES
(25, 1, 3, 'day', '2019-03-07', '08:10:00', '17:00:00', 'present', NULL, NULL),
(26, 3, 3, 'day', '2019-03-07', '09:10:00', '19:00:00', 'present', NULL, NULL),
(27, 4, 3, 'day', '2019-03-07', '08:30:00', '18:00:00', 'present', NULL, NULL),
(28, 5, 3, 'day', '2019-03-07', '08:15:00', '20:15:00', 'present', NULL, NULL),
(29, 1, 3, 'day', '2019-03-06', '08:00:00', '17:30:00', 'present', NULL, NULL),
(30, 3, 3, 'day', '2019-03-06', '08:30:00', '18:10:00', 'present', NULL, NULL),
(31, 4, 3, 'day', '2019-03-06', '00:00:00', '00:00:00', 'absent', NULL, NULL),
(32, 5, 3, 'day', '2019-03-06', '00:00:00', '17:00:00', 'present', NULL, NULL),
(33, 6, 4, 'night', '2019-03-08', '08:59:00', '22:00:00', 'present', NULL, NULL),
(34, 1, 3, 'day', '2019-03-23', '08:00:00', '17:00:00', 'present', NULL, NULL),
(35, 3, 3, 'day', '2019-03-23', '08:00:00', '17:00:00', 'present', NULL, NULL),
(36, 4, 3, 'day', '2019-03-23', '08:00:00', '17:00:00', 'present', NULL, NULL),
(37, 5, 3, 'day', '2019-03-23', '08:00:00', '17:00:00', 'present', NULL, NULL),
(38, 1, 3, 'day', '2019-04-03', '08:00:00', '17:00:00', 'present', NULL, NULL),
(39, 3, 3, 'day', '2019-04-03', '08:00:00', '20:10:00', 'present', NULL, NULL),
(40, 4, 3, 'day', '2019-04-03', '08:00:00', '21:00:00', 'present', NULL, NULL),
(41, 5, 3, 'day', '2019-04-03', '08:00:00', '17:00:00', 'present', NULL, NULL),
(42, 1, 3, 'day', '2019-04-18', '08:00:00', '17:00:00', 'present', NULL, NULL),
(43, 3, 3, 'day', '2019-04-18', '08:00:00', '17:00:00', 'present', NULL, NULL),
(44, 4, 3, 'day', '2019-04-18', '08:00:00', '17:00:00', 'present', NULL, NULL),
(45, 5, 3, 'day', '2019-04-18', '08:00:00', '17:00:00', 'present', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

CREATE TABLE `tbl_department` (
  `department_id` int(10) UNSIGNED NOT NULL,
  `department_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_department`
--

INSERT INTO `tbl_department` (`department_id`, `department_name`, `created_at`, `updated_at`) VALUES
(1, 'Cutting', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_designation`
--

CREATE TABLE `tbl_designation` (
  `designation_id` int(10) UNSIGNED NOT NULL,
  `department_id` int(20) NOT NULL,
  `designation_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_designation`
--

INSERT INTO `tbl_designation` (`designation_id`, `department_id`, `designation_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'Cutting Helper', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE `tbl_employee` (
  `employee_id` int(10) UNSIGNED NOT NULL,
  `unit_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `employee_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_date_of_birth` date NOT NULL,
  `employee_join_date` date NOT NULL,
  `employee_nid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_father_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_mother_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `employee_parmanent_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_present_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `employee_status` int(10) NOT NULL,
  `shift_name` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`employee_id`, `unit_id`, `designation_id`, `grade_id`, `employee_name`, `employee_phone`, `employee_email`, `employee_date_of_birth`, `employee_join_date`, `employee_nid`, `employee_father_name`, `employee_mother_name`, `employee_parmanent_address`, `employee_present_address`, `employee_photo`, `employee_status`, `shift_name`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 1, 'Mainul Hasan', '01455454545', 'mainul@gmail.com', '1995-03-04', '2019-03-04', '457654124543415', 'Abdul Haque', 'Kaniz', 'Tangail, Modhupur', 'Gazipur', 'employee/54NeCAbLph7Bop9ruJJV.jpg', 1, 'day', NULL, NULL),
(2, 3, 1, 1, 'Sruti Hasan', '01546465454', 'srutihasan@gmail.com', '1989-03-05', '2019-03-05', '544545546354', 'Satta Murti', 'Salma Haque', 'Tongi, Gazipur', 'Uttara, Dhaka', 'employee/qFTud8yjONxpj1vgmCCp.jpg', 2, 'day', NULL, NULL),
(3, 3, 1, 1, 'Mijanur rahman', '01247859201', NULL, '2019-03-05', '2016-01-03', '01222365478996', 'mijjafs', 'maosfinosadfa', 'maosifafn afja ofoasf', 'asfoaijf sijdf q w', 'employee/qL3CVIJ4qWbLCM22nQqn.jpg', 1, 'day', NULL, NULL),
(4, 3, 1, 1, 'shakil', '01223654778', NULL, '2019-03-05', '2019-03-05', '0125545563', 'sadjfdmlsf', 'as cdf', 'jasdflaf alskjdflak', 'asfciosaijfmajc x', 'employee/bRZbYj1Q1ny9nQscEohb.pdf', 1, 'day', NULL, NULL),
(5, 3, 1, 1, 'Naina', '48546512545', 'naina@email.com', '1995-03-05', '2019-03-05', '4546424578', 'Kabir', 'Hena', 'Tongi', 'Dhaka', 'employee/NMkUusI9WdYZtA8gJ5O9.jpg', 1, 'day', NULL, NULL),
(6, 4, 1, 1, 'Jamal', '01742503080', 'jamal@gmail.com', '1997-03-08', '2016-01-11', '125478965125212654', 'mad.jahid', 'mother india', 'eagaefvg', 'dafagds', 'employee/fPntoq6YmSQBKlnXwPIk.png', 1, 'night', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_festible`
--

CREATE TABLE `tbl_festible` (
  `festible_id` int(10) UNSIGNED NOT NULL,
  `festible_date` date NOT NULL,
  `festible` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_festible`
--

INSERT INTO `tbl_festible` (`festible_id`, `festible_date`, `festible`, `created_at`, `updated_at`) VALUES
(1, '2019-04-13', 'no', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_grade`
--

CREATE TABLE `tbl_grade` (
  `grade_id` int(10) UNSIGNED NOT NULL,
  `grade_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_salary` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `basic_salary` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `home_rent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `medical_allowance` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transport_allowance` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lunch_allowance` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `festible_bonus` int(10) NOT NULL,
  `ot_rate` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `holiday_bonus` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `holiday` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_grade`
--

INSERT INTO `tbl_grade` (`grade_id`, `grade_name`, `total_salary`, `basic_salary`, `home_rent`, `medical_allowance`, `transport_allowance`, `lunch_allowance`, `festible_bonus`, `ot_rate`, `holiday_bonus`, `holiday`, `created_at`, `updated_at`) VALUES
(1, 'G-7', '8000', '4100', '2050', '600', '350', '900', 4500, '39.42', '160', '2', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_leave`
--

CREATE TABLE `tbl_leave` (
  `leave_id` int(10) UNSIGNED NOT NULL,
  `employee_id` int(11) NOT NULL,
  `leave_date` date NOT NULL,
  `leave_purpose` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_leave`
--

INSERT INTO `tbl_leave` (`leave_id`, `employee_id`, `leave_date`, `leave_purpose`, `created_at`, `updated_at`) VALUES
(1, 1, '2019-03-17', '', NULL, NULL),
(2, 1, '2019-03-21', '', NULL, NULL),
(3, 1, '2019-03-19', 'Fever', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_office`
--

CREATE TABLE `tbl_office` (
  `office_id` int(10) UNSIGNED NOT NULL,
  `office_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_office`
--

INSERT INTO `tbl_office` (`office_id`, `office_name`, `created_at`, `updated_at`) VALUES
(3, 'New Dacca', NULL, NULL),
(4, 'Yellow', NULL, NULL),
(5, 'IKAL', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_salary`
--

CREATE TABLE `tbl_salary` (
  `salary_id` int(10) UNSIGNED NOT NULL,
  `employee_id` int(11) NOT NULL,
  `office_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `grade_id` int(11) NOT NULL,
  `designation_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `bonus` int(11) NOT NULL,
  `fine` int(11) NOT NULL,
  `total_salary` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_salary`
--

INSERT INTO `tbl_salary` (`salary_id`, `employee_id`, `office_id`, `unit_id`, `grade_id`, `designation_id`, `department_id`, `bonus`, `fine`, `total_salary`, `created_at`, `updated_at`) VALUES
(1, 1, 3, 3, 1, 1, 1, 320, 0, 586, '2019-04-16 12:40:44', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_unit`
--

CREATE TABLE `tbl_unit` (
  `unit_id` int(10) UNSIGNED NOT NULL,
  `office_id` int(11) NOT NULL,
  `unit_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_unit`
--

INSERT INTO `tbl_unit` (`unit_id`, `office_id`, `unit_name`, `created_at`, `updated_at`) VALUES
(3, 3, 'Unit-1', NULL, NULL),
(4, 4, 'Unit-1', NULL, NULL),
(5, 4, 'Unit-2', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_department`
--
ALTER TABLE `tbl_department`
  ADD PRIMARY KEY (`department_id`);

--
-- Indexes for table `tbl_designation`
--
ALTER TABLE `tbl_designation`
  ADD PRIMARY KEY (`designation_id`);

--
-- Indexes for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `tbl_festible`
--
ALTER TABLE `tbl_festible`
  ADD PRIMARY KEY (`festible_id`);

--
-- Indexes for table `tbl_grade`
--
ALTER TABLE `tbl_grade`
  ADD PRIMARY KEY (`grade_id`);

--
-- Indexes for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  ADD PRIMARY KEY (`leave_id`);

--
-- Indexes for table `tbl_office`
--
ALTER TABLE `tbl_office`
  ADD PRIMARY KEY (`office_id`);

--
-- Indexes for table `tbl_salary`
--
ALTER TABLE `tbl_salary`
  ADD PRIMARY KEY (`salary_id`);

--
-- Indexes for table `tbl_unit`
--
ALTER TABLE `tbl_unit`
  ADD PRIMARY KEY (`unit_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `admin_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_attendance`
--
ALTER TABLE `tbl_attendance`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `tbl_department`
--
ALTER TABLE `tbl_department`
  MODIFY `department_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_designation`
--
ALTER TABLE `tbl_designation`
  MODIFY `designation_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_employee`
--
ALTER TABLE `tbl_employee`
  MODIFY `employee_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_festible`
--
ALTER TABLE `tbl_festible`
  MODIFY `festible_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_grade`
--
ALTER TABLE `tbl_grade`
  MODIFY `grade_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_leave`
--
ALTER TABLE `tbl_leave`
  MODIFY `leave_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tbl_office`
--
ALTER TABLE `tbl_office`
  MODIFY `office_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_salary`
--
ALTER TABLE `tbl_salary`
  MODIFY `salary_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_unit`
--
ALTER TABLE `tbl_unit`
  MODIFY `unit_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
